  <!-- Start Content -->
<style>
    .img-fluid{
        width: 100% !important;
        height: 430px;
        margin-top: 45px !important;
    }
</style>
    <div class="col-lg-12" style="background-color:#f3f3f3">
     
    <div class="sim-slider" data-width="2550" data-height="660" data-animation="350" data-current="false"data-progress="false">   
                
                <div class="sim-slider-slide">
                    <div class="sim-slider-layer" data-effect="rollIn" data-width="767" data-height="500" data-left="1678" data-top="150"><img src="_assets/layer_00055.png" /></div> 
                    <div class="sim-slider-layer" data-effect="rollIn" data-width="767" data-height="500" data-left="896" data-top="150"><img src="_assets/layer_00033.png" /></div> 
                    <div class="sim-slider-layer" data-effect="rollIn" data-width="767" data-height="500" data-left="115" data-top="150"><img src="_assets/layer_00044.png" /></div> 
                </div>
                    
                <div class="sim-slider-slide">
                    <div class="sim-slider-layer" data-effect="rollIn" data-width="767" data-height="500" data-left="115" data-top="150"><img src="_assets/layer_00055.png" /></div> 
                    <div class="sim-slider-layer" data-effect="rollIn" data-width="767" data-height="500" data-left="896" data-top="150"><img src="_assets/layer_00033.png" /></div> 
                    <div class="sim-slider-layer" data-effect="rollIn" data-width="767" data-height="500" data-left="1678" data-top="150"><img src="_assets/layer_00044.png" /></div> 
                </div>      
                        
            </div>
    </div>
   <?php /**PATH C:\wamp64\www\iratic-projet\resources\views/front/slider.blade.php ENDPATH**/ ?>